<?php

/*
Plugin Name: Naatan.com MyStats (without sessions)
Plugin URI: http://www.naatan.com/?page_id=63
Description: Shows some info about the visitor concerning his/her activity on your website.
Version: 1.0
Author: Nathan
Author URI: http://www.naatan.com/
*/

// ## Create Template if it doesn't Excist yet ##
if (!get_option('naatan_mystats_template')) {
	add_option("naatan_mystats_template","<li><h2>MyStats</h2>
	<ul>
Welcome back, <a href=\"%visitor_website%\" target=\"_blank\">%visitor_name%</a>!<br><br>
<img src=\"%visitor_gravatar%\" align=\"left\">
 <b>%visitor_newcomments%</b> new comments<br>
 <b>%visitor_newblogs%</b> new blogs<br>
 since your last comment.<br><br>
You've made <b>%visitor_totalcomments%</b> cmnts on my blog.<br>
Click <a href=\"index.php?p=%visitor_lastblog%\">here</a> to see my last entry.
	</ul>
</li>");
}
if (!get_option('naatan_mystats_guesttemplate')) {
	add_option("naatan_mystats_guesttemplate","<li><h2>MyStats</h2>
	<ul>
Welcome to my website, leave a comment! :)
	</ul>
</li>");
}
if (!get_option('naatan_mystats_avatarsize')) {
	add_option("naatan_mystats_avatarsize",'100');
}

// ## Get visitor IP ##
function naatan_v_get_IP() {
	if (empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
		$ip_address = $_SERVER["REMOTE_ADDR"];
	} else {
		$ip_address = $_SERVER["HTTP_X_FORWARDED_FOR"];
	}
	if(strpos($ip_address, ',') !== false) {
		$ip_address = explode(',', $ip_address);
		$ip_address = $ip_address[0];
	}
	return $ip_address;
}

// ## The Script for the Output Function ##
function naatan_mystats() {

	global $wpdb;

	// ## Get Visitor Name ##
	if ($comment_author = $_COOKIE['comment_author_'.COOKIEHASH]) {
		$wherecause = "comment_author='$comment_author'";
		$visited = TRUE;
	} elseif ($wpdb->get_row("SELECT * FROM $wpdb->comments WHERE comment_author_IP='".naatan_v_get_IP()."'")) {
		$wherecause = "comment_author_IP='".naatan_v_get_IP()."'";
		$visited = TRUE;
	} else {
		$visited = FALSE;
	}

	// ## Get Visitor Details ##
	if ($visited!=FALSE) {

		// Get last comment made by visitor
		$vq = $wpdb->get_row("SELECT * FROM $wpdb->comments WHERE $wherecause ORDER BY comment_ID DESC LIMIT 1");
		$visitor['name'] = $vq->comment_author;
		$visitor['email'] = $vq->comment_author_email;
		$visitor['website'] = $vq->comment_author_url;
	
		// Get number comments made by visitor
		$vcq = $wpdb->get_row("SELECT COUNT(comment_ID) AS count FROM $wpdb->comments WHERE $wherecause");
		$visitor['totalcomments'] = $vcq->count;
	
		// Get number of new comments
		$cq = $wpdb->get_row("SELECT COUNT(comment_ID) AS count FROM $wpdb->comments WHERE comment_ID>$vq->comment_ID");
		$visitor['newcomments'] = $cq->count;
	
		// Get number of new blogs
		$bq = $wpdb->get_row("SELECT COUNT(ID) AS count FROM $wpdb->posts WHERE ID>$vq->comment_post_ID AND post_status='publish'");
		$visitor['newblogs'] = $bq->count;
	
		// Get last blog
		$lbq = $wpdb->get_row("SELECT * FROM $wpdb->posts WHERE post_status='publish' ORDER BY ID DESC LIMIT 1");
		$visitor['lastblog'] = $lbq->ID;
	
		// Get Gravatar URL
		$grav_url = "http://www.gravatar.com/avatar.php?gravatar_id=".md5($visitor['email'])."&amp;size=".get_option('naatan_mystats_avatarsize');
	
		// Replace template tags
		$mystats_template = get_option('naatan_mystats_template');
		$mystats_template = str_replace("%visitor_name%",$visitor['name'],$mystats_template);
		$mystats_template = str_replace("%visitor_email%",$visitor['email'],$mystats_template);
		$mystats_template = str_replace("%visitor_website%",$visitor['website'],$mystats_template);
		$mystats_template = str_replace("%visitor_newcomments%",$visitor['newcomments'],$mystats_template);
		$mystats_template = str_replace("%visitor_newblogs%",$visitor['newblogs'],$mystats_template);
		$mystats_template = str_replace("%visitor_totalcomments%",$visitor['totalcomments'],$mystats_template);
		$mystats_template = str_replace("%visitor_lastblog%",$visitor['lastblog'],$mystats_template);
		$mystats_template = str_replace("%visitor_gravatar%",$grav_url,$mystats_template);
	
		// ## Return Output ##
		echo $mystats_template;
	
	} else {

		// ## Return Guest Outpit ##
		echo get_option('naatan_mystats_guesttemplate');

	}

}

// ## The Admin Page ##
function naatan_mystats_options() {

	// Save new settings
    if ($_POST['save_settings']) {
		update_option("naatan_mystats_avatarsize", stripslashes($_POST['naatan_mystats_avatarsize']));
		update_option("naatan_mystats_template", stripslashes($_POST['naatan_mystats_template']));
		update_option("naatan_mystats_guesttemplate", stripslashes($_POST['naatan_mystats_guesttemplate']));
    }

	// Output the options Page
	echo '
	
	<div class="wrap">
		<h2>MyStats Options</h2>
		<form name="form" method="post" action="'.$_SERVER['REQUEST_URI'].'">
			<fieldset class="options">
				<legend>Gravatar</legend>
				<blockquote><input type="text" name="naatan_mystats_avatarsize" size="20" value="'.get_option('naatan_mystats_avatarsize').'"> Please specify the avatar size</blockquote>
			</fieldset>
			<fieldset class="options">
				<legend>Visitor Template</legend>
				<blockquote>
					Below template is displayed when a user that has made a previous comment visits your site.<br>
					You can use any of the following tags:
					<ul>
						<li><b>%visitor_name%</b> - Returns the name of the visitor, collected by cookies or IP.</li>
						<li><b>%visitor_email%</b> - Returns the E-Mail of the visitor as set in the last comment.</li>
						<li><b>%visitor_website%</b> - Returns the website of the visitor.</li>
						<li><b>%visitor_newcomments%</b> - Returns the amount of new comments since the visitors last comment.</li>
						<li><b>%visitor_newblogs%</b> - Returns the amount of new blogs since the visitors last comment.</li>
						<li><b>%visitor_totalcomments%</b> - Returns the total amount of comments the visitor has made.</li>
						<li><b>%visitor_lastblog%</b> - Returns the ID of the last posted blog.</li>
						<li><b>%visitor_gravatar%</b> - Returns URL for gravatar.</li>
					</ul>
					Ideas for more tags? <a href="mailto:n.rijksen@hotmail.com">Let me know</a>.<br>
					<textarea rows="10" name="naatan_mystats_template" cols="70">'.get_option('naatan_mystats_template').'</textarea>
				</blockquote>
			</fieldset>
			<fieldset class="options">
				<legend>Guest Template</legend>
				<blockquote>
					Below template is displayed when a user with no previous comments on your site visits.
					<textarea rows="10" name="naatan_mystats_guesttemplate" cols="70">'.get_option('naatan_mystats_guesttemplate').'</textarea>
				</blockquote>
			</fieldset>
			<input type="submit" name="save_settings" value="Save Settings">
		</form>
	</div>
	
	';

}

// ## Add link to the Admin panel ##
function Mystats_add_pages() {
    add_options_page('MyStats', 'MyStats', 8, __FILE__, 'naatan_mystats_options');
}

add_action('admin_menu', 'Mystats_add_pages');

?>