#######################################################
Plugin Name: Naatan.com MyStats
Plugin URI: http://www.naatan.com/?page_id=63
Description: Shows some info about the visitor concerning his/her activity on your website.
Version: 1.0
Author: Nathan
Author URI: http://www.naatan.com/
#######################################################

==========
READ FIRST
==========

I have released two versions of this plugin, one that's supporting sessions and one that isn't.
The reason I did this is because some servers don't support the use of sessions, also the script I wrote
creates a new session and this might give errors if other plugins you might be using do the same.
I would advice you to install the plugin that supports sessions, if this gives errors simply install the other one.

The biggest difference is that the plugin with sessions shows you comments/blogs since your last visited date.
The plugin without sessions shows them since your last comment.

=========================
INSTALLATION INSTRUCTIONS
=========================

* Upload the files to your plugins directory
  - naatan_mystats_with-sessions.php *Upload this file if you want to use sessions*
  - naatan_mystats_without-sessions.php *Upload this file if you don't want to use sessions*
* Enable the plugin in WP Plugin Management
* Open up your sidebar template (or any other template you want to place it in)
* Add the following where you want the plugin to appear;

----(Start Copying Below)-----

<?php naatan_mystats(); ?>

----(Stop Copying)-----

* Save Template
* Done!

=============
CONFIGURATION
=============

When you enable the plugin a little MyStats header will appear at the admin panel options pages.
You can specify two templates, one for when a visitor with previous comments visits and one for new visitors
that do not have a name specified.
If you don't want new visitors to get a MyStats menu simply leave that template empty.

====
DEMO
====

All my scripts are developed, tested and previewed at;

http://www.naatan.com/wordpress/

======
ENJOY!
======